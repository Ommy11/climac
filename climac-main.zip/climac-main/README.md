# Climac
<a href="https://twitter.com/ADITYAVOFFICIAL" ><img src="https://img.shields.io/twitter/follow/ADITYAVOFFICIAL.svg?style=social" /> </a>
<br>
<a href="https://github.com/ADITYAVOFFICIAL/awesome-github-profile-readme/issues"><img src="https://img.shields.io/github/issues/ADITYAVOFFICIAL/awesome-github-profile-readme" alt="Issues Badge"/></a>
<p align = "center">
  <img src = "https://github-readme-stats.vercel.app/api?username=ADITYAVOFFICIAL&show_icons=true&theme=bear" width = 400>
  <img src = "https://github-readme-streak-stats.herokuapp.com?user=ADITYAVOFFICIAL&theme=dark&hide_border=true" width = 400>
</p>
 WELCOME TO THE CLIMAC WEBSITE/WEBAPP  <br>

PROGRAM USED<br>
>> HTML5, CSS<br>
>> BOOTSTRAP V5<br>
>> JQUERY<br>
>> JAVASCRIPT<br>
>> MS VISUAL STUDIO CODE<br>
>> Windows 10 Version 21H1 X64<br>

$$DESCRIPTION$$<br>

This website/webapp [Android app included] is based on the 13th Goal of the UN Sustainable Development Goals (Climate Action).<br>
This website shares information on climate change (evidence, causes, effects and solutions ) along with satellite images which<br>
show the devastation and destruction caused by the negative change in climate due to human interference & negligence,<br>
a live counter depicting the abnormal parameters of the earth (climate change) with a quiz for the viewers.<br>
This website/webapp also includes how we can achieve the 13th goal of the UN Sustainable Development <br>
$ Mobile App also developed and available $. First, to access the website/webapp use the link given below<br>
and click on let’s go and wait, it will redirect you to the main website/webapp.<br>

DURATION IN MAKING = 26 DAYS<br>
AUTHOR = ADITYA VERMA<br>
FINIALIZATION DATE = 16 AUGUST 2021<br>


</> FILE Count  </><br>
TOTAL = 33<br>
HTML FILES = 29<br>
JS FILES = 3<br>
CSS FILES = 3<br>
SAT IMAGES = 22<br>
MAIN TOPIC = 4<br>
MISC = 2<br>

instagram = https://www.instagram.com/aditya_verma_real/ <br>
TWITTER = https://twitter.com/ADITYAVOFFICIAL<br>
GITHUB = https://github.com/ADITYAVOFFICIAL<br>
