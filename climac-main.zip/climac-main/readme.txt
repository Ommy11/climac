$$  WELCOME TO THE CLIMAC WEBSITE  $$

PROGRAM USED
>> HTML5, CSS
>> BOOTSTRAP V5
>> JQUERY
>> JAVASCRIPT
>> MS VISUAL STUDIO CODE
>> Windows 10 Version 21H1 X64

$$DESCRIPTION$$

This website/webapp [Android app included] is based on the 13th Goal of the UN Sustainable Development Goals (Climate Action).
This website shares information on climate change (evidence, causes, effects and solutions ) along with satellite imageswhich show the devastation and destruction caused by the negative change in climate due to human interference & negligence,
a live counter depicting the abnormal parameters of the earth (climate change) with a quiz for the viewers.
This website/webapp also includes how we can achieve the 13th goal of the UN Sustainable Development 
$ Mobile App also developed and available $. First, to access the website/webapp use the link given below
and click on let’s go and wait, it will redirect you to the main website/webapp.

DURATION IN MAKING = 26 DAYS
AUTHOR = ADITYA VERMA
FINIALIZATION DATE = 16 AUGUST 2021


</> FILE Count  </>
TOTAL FILES = 33
HTML FILES = 29
JS FILES = 3
CSS FILES = 3
sat images = 22
main topic = 4
MISC = 2

instagram = https://www.instagram.com/aditya_verma_real/
TWITTER = https://twitter.com/ADITYAVOFFICIAL
GITHUB = https://github.com/ADITYAVOFFICIAL

<!-- =======================================================
  * Website Name: Climac
  * URL: https://Climac.adityavermareal.repl.co/
  * Author: Aditya Verma
  * GitHub: https://github.com/ADITYAVOFFICIAL/climac
======================================================== -->